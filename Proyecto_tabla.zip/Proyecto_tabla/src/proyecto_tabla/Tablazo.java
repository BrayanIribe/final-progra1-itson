
package proyecto_tabla;

public class Tablazo {

    public static void main(String[] args) {
        
        // esi = esquina superior izquierda | esd = esquina inferior derecha
        char esi = '\u250C';
        char esd = '\u2510';
        
        // esh = espacio horizontal | esv = espacio vertical
        char esh = '\u2500';
        char esv = '\u2502';
        
        // uli = union lateral izquierda | uld = union lateral derecha
        char uli = '\u251C';
        char uld = '\u2524';
        
        // us = union superior | ui= union inferior
        char us = '\u252C';
        char ui = '\u2534';
        
        // udc = union de cuatro lados
        char udc = '\u253C';
        
        // eii = esquina inferior derecha | eid = esquina inferior derecha
        char eii = '\u2514';
        char eid = '\u2518';
        
        //PRIMER TABLA
        //linea superior
        System.out.printf("%10s%1s","",esi);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s", us);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s%2s", esd,"");
        System.out.printf("%2s%1s","",esi);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s", us);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s%n", esd);
        
        //linea informacion
        System.out.printf("%10s%1s","",esv);
        for(int i = 0 ; i < 2 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.printf("%5s",esv);
        for(int i = 2 ; i < 4 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.println("");
        
        //linea inferior
        System.out.printf("%10s%1s","",eii);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s", ui);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s%2s", eid,"");
        System.out.printf("%2s%1s","",eii);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s", ui);
        for(int i = 0 ; i < 9 ; i++){
            System.out.printf("%1s",esh);
        }
        System.out.printf("%1s%n", eid);
            
        //SEGUNDA TABLA
        //linea superior
        System.out.printf("%1s",esi);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", us);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%4s%1s", esd,"",esi);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", us);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%n", esd);
        
        //linea informacion 01
        System.out.printf("%1s",esv);
        for(int i = 0 ; i < 3 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.printf("%5s",esv);
        for(int i = 3 ; i < 6 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.println("");
        
        //linea division
        System.out.printf("%1s",uli);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", udc);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%4s%1s", uld,"",uli);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", udc);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%n", uld);
        
        //linea informacion 02
        System.out.printf("%1s",esv);
        for(int i = 6 ; i < 9 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.printf("%5s",esv);
        for(int i = 9 ; i < 12 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.println("");
        
        //linea division
        System.out.printf("%1s",uli);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", udc);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%4s%1s", uld,"",uli);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", udc);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%n", uld);
        
        //linea informacion 03
        System.out.printf("%1s",esv);
        for(int i = 12 ; i < 15 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.printf("%5s",esv);
        for(int i = 15 ; i < 18 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.println("");
        
        //linea division
        System.out.printf("%1s",uli);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", udc);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%4s%1s", uld,"",uli);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", udc);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%n", uld);
        
        //linea informacion 04
        System.out.printf("%1s",esv);
        for(int i = 18 ; i < 21 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.printf("%5s",esv);
        for(int i = 21 ; i < 24 ; i++){
                System.out.printf("%1s%2s%5s%2s","",i,i+100,esv);
        }
        System.out.println("");
        
        //linea inferior
        System.out.printf("%1s",eii);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", ui);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%4s%1s", eid,"",eii);
        for(int b = 0 ; b < 2 ; b++){
            for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
            System.out.printf("%1s", ui);
        }
        for(int i = 0 ; i < 9 ; i++){
                System.out.printf("%1s",esh);
            }
        System.out.printf("%1s%n", eid);
    }
}
